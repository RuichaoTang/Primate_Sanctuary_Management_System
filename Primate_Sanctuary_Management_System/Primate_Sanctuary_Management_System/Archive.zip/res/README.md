Read me
1. To receive a new monkey into the sanctuary, make sure you enter a unique name and full information for every single monkey.
After filling the blank, hit "Receive" button.
2. When receiving new monkeys, you will get notified if there is no room for new monkeys (because the isolation cages are full).
3. To give medical care to a specific monkey, please enter the monkey's name in the name text filed. And then hit "Health Check" button.
4. when a monkey's health status is unknown, if you move that monkey to enclosure, the result text filed will display "The monkey has not been tested healthy.".
5. To print an enclosure, select a specie and then hit the "Print Enclosure" button.
6. To print all monkey's name (in alphabetical order), hit "Show All" button.