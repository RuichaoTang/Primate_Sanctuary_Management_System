package sanctuary;

public class Main {
    public static void main(String[] args){
        // create a sanctuary
        Sanctuary sanc = new Sanctuary();
        Monkeys mon1 = new Monkeys("Abby",Species.GUEREZA,Sex.MALE,56,66,4,Foods.FRUITS);
        // add a monkey into this sanctuary
        sanc.receiveNewMonkey(mon1);
        Monkeys mon2 = new Monkeys("Sandy",Species.GUEREZA,Sex.FEMALE,48,56,2,Foods.EGGS);
        sanc.receiveNewMonkey(mon2);
        Monkeys mon3 = new Monkeys("Brian",Species.HOWLER,Sex.MALE,38,26,1,Foods.SEEDS);
        sanc.receiveNewMonkey(mon3);

        // Print monkeys in the isolation
        System.out.println("Print monkeys in the isolation");
        System.out.println(sanc.printIsolation());

        // Move monkeys into the enclosures
        sanc.giveMedical(mon1);
        sanc.moveToEnclosure(mon1);
        sanc.giveMedical(mon2);
        sanc.moveToEnclosure(mon2);
        sanc.giveMedical(mon3);
        sanc.moveToEnclosure(mon3);

        // Print all monkey in this sanctuary
        System.out.println("Print all monkey in this sanctuary");
        System.out.println(sanc.printAllMonkeys());


        // Print monkeys in given enclosures
        System.out.println("Monkeys in Guereza enclosure:");
        System.out.println(sanc.printMonkeysInEnclosure(Species.GUEREZA));
        System.out.println("Monkeys in Howler enclosure:");
        System.out.println(sanc.printMonkeysInEnclosure(Species.HOWLER));
        // when the enclosure is empty
        System.out.println("Monkeys in Saki enclosure:");
        System.out.println(sanc.printMonkeysInEnclosure(Species.SAKI));
    }
}
