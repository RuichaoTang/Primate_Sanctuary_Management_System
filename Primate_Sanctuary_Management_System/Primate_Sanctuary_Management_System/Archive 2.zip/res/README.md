# Primate Sanctuary Management System

## Overview
The Sanctuary Application is a Java application designed to manage a primate sanctuary. The system allows users to perform the following operations:

1. register new monkeys into the sanctuary (straight into the isolation area).
2. Transfer monkeys that have received medical attention to the right enclosure.
3. View the list of all monkeys in a specific enclosure.
4. View the list of all monkeys housed in the sanctuary.

## System Components
The system consists of the following main components:
1. `Enclosure` represent the interface of the enclosure class.
2. `Monkeys`: Represents a primate, with attributes such as name, species, sex, size, weight, age, and favorite food.
3. `IsolationClass`: Responsible for managing the isolation area, including adding and removing primates.
4. `EnclosureClass`: Responsible for managing the enclosures for specific species, including adding and removing primates.
5. `Sanctuary`: represent the Sanctuary.
6. `JFrameView`: Provides a graphical user interface (GUI) for interacting with the system.
7. `SancController`: Handles user interface events and calls the corresponding Sanctuary methods.
8. `Demo`: The entry point of the program, responsible for creating the Sanctuary, SanctuaryView, and SanctuaryController instances and starting the application

## Usage
1. Run the `Demo` class to start the application.
2. In the GUI interface, you can perform the following actions:
   - To receive a new monkey into the sanctuary, make sure you enter a unique name and full information for every single monkey.
   After filling the blank, hit "Receive" button. 
   - When receiving new monkeys, you will get notified if there is no room for new monkeys (because the isolation cages are full). 
   - To give medical care to a specific monkey, please enter the monkey's name in the name text filed. And then hit "Health Check" button.
   - when a monkey's health status is unknown, if you move that monkey to enclosure, the result text filed will display "The monkey has not been tested healthy.". 
   - To print an enclosure, select a specie and then hit the "Print Enclosure" button. 
   - To print all monkey's name (in alphabetical order), hit "Show All" button.

## Testing
The system includes a set of JUnit 4 test cases located in the `/test` directory. These test cases cover the following functionalities:
1. Creation of Monkeys: Tests to ensure that monkeys can be created successfully and that invalid inputs are handled appropriately.
2. Isolation Management: Tests related to adding monkeys to the isolation area, including handling capacity constraints.
3. Moving Monkeys to Enclosures: Tests to verify that healthy monkeys can be moved to enclosures and that attempts to move unhealthy monkeys are rejected.
4. Species Reporting: Tests for generating accurate reports on the species present in the sanctuary.
5. Listing Monkeys in Enclosures: Tests to ensure that the list of monkeys in each enclosure is generated correctly.
6. Ordering Monkeys by Name: Tests to validate the sorting order of monkeys by name.

## Contact
If you have any questions or feedback, please contact:
- Email: tang.ruic@northeastern.edu
- Phone: 628-231-9242